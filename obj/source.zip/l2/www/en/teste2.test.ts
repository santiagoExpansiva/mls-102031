/// <mls fileReference="_102031_/l2/www/en/teste2.test.ts" enhancement="_blank"/>

 import { ICANTest, ICANIntegration, ICANSchema  } from '/_100554_/l2/tsTestAST.js';
 export const integrations: ICANIntegration[] = [];
 export const tests: ICANTest[] = [];