/// <mls fileReference="_102031_/l2/www/en/landingpage1.defs.ts" enhancement="_blank"/>
export const asis = {
    "meta": {
        "fileReference": "_102031_/l2/www/en/landingpage1.ts",
        "componentType": "page",
        "componentScope": "appFrontEnd",
        "languages": [
            "en"
        ]
    },
    "references": {
        "webComponents": [],
        "imports": []
    },
    "codeInsights": {
        "unusedImports": []
    },
    "asIs": {
        "semantic": {
            "generalDescription": "TypeScript class CollabMessagesEn102031 extending CollabPageElement",
            "businessCapabilities": [],
            "technicalCapabilities": [],
            "implementedFeatures": [],
            "constraints": []
        }
    }
};
