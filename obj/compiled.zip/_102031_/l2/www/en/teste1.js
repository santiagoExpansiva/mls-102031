/// <mls fileReference="_102031_/l2/www/en/teste1.ts" enhancement="_100554_enhancementLit"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_100554_/l2/stateLitElement.js';
let Teste1102031 = class Teste1102031 extends StateLitElement {
    constructor() {
        super(...arguments);
        this.name = 'Somebody';
    }
    render() {
        return html `<p> Hello, ${this.name} !</p>`;
    }
};
__decorate([
    property()
], Teste1102031.prototype, "name", void 0);
Teste1102031 = __decorate([
    customElement('www--en--teste1-102031')
], Teste1102031);
export { Teste1102031 };
