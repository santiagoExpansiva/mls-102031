/// <mls fileReference="_102031_/l2/www/en/corporate.ts" enhancement="_102020_enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { customElement } from 'lit/decorators.js';
import { CollabLandingPage } from '_102032_/l2/collabLandingPage';
let CollabMessagesEn102031 = class CollabMessagesEn102031 extends CollabLandingPage {
    firstUpdated() { }
};
CollabMessagesEn102031 = __decorate([
    customElement('www--en--corporate-102031')
], CollabMessagesEn102031);
export { CollabMessagesEn102031 };
