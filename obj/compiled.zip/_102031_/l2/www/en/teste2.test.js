/// <mls fileReference="_102031_/l2/www/en/teste2.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
