"use strict";
/// <mls fileReference="_102031_/l2/www/index.ts" enhancement="_102032_/l2/enhancementLandingPage" />
function prepareNavigation() {
    const SUPPORTED = ['pt', 'en'];
    const DEFAULT = 'en';
    const browserLang = (navigator.language || DEFAULT)
        .slice(0, 2)
        .toLowerCase();
    console.info(browserLang);
    const lang = SUPPORTED.includes(browserLang) ? browserLang : DEFAULT;
    const messages = {
        pt: 'Seja bem-vindo ao Collab.codes! Você está sendo redirecionado à página inicial.',
        en: 'Welcome to Collab.codes! You are being redirected to the home page.'
    };
    const msg = document.querySelector('#msg');
    if (!msg)
        return;
    msg.textContent = messages[lang];
    setTimeout(() => {
        const dest = `/${lang}/landingpage.html`;
        //${location.search}${location.hash}`;
        window.location.replace(dest);
    }, 2000);
}
prepareNavigation();
