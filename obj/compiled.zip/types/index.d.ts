declare module "_102031_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/designSystem" {
    import { IDesignSystemTokens } from '_100554_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102031_/l2/project.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102031_/l2/www/en/corporate.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/corporate.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/index.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/index.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/landingpage.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/landingpage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare function setEvents(): void;
declare function _handleSignIn(): void;
declare const sectionVideos: SectionVideos;
declare function renderVideoSection(sectionVideos: SectionVideos): void;
declare function setScrollEffects(): void;
declare function setLoginEvent(): void;
interface Video {
    title: string;
    description: string;
}
interface VideoGroup {
    title: string;
    videos: Video[];
}
interface SectionVideos {
    title: string;
    [key: string]: string | VideoGroup;
}
declare module "_102031_/l2/www/en/policy.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/policy.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/terms.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102031_/l2/www/en/terms.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
