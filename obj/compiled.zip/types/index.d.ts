declare module "_102031_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/designSystem" {
    import { IDesignSystemTokens } from '_100554_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102031_/l2/policy.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/policy" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class PolicyEn102031 extends CollabLitElement {
        private myMessage;
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/project.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102031_/l2/terms.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/terms" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class TermsEn102031 extends CollabLitElement {
        private myMessage;
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/en/collabMessages.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/en/collabMessages" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class CollabMessagesEn102031 extends CollabLitElement {
        private myMessage;
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/en/initial.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/en/initial" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class Initial102031 extends CollabLitElement {
        private myMessage;
        private _handleSignIn;
        render(): any;
    }
}
declare module "_102031_/l2/en/initial2.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/en/initial2" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class Initial2En102031 extends CollabLitElement {
        private myMessage;
        private _handleAction;
        render(): any;
    }
}
declare module "_102031_/l2/en/policy.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/en/policy" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class PolicyEn102031 extends CollabLitElement {
        private myMessage;
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/en/terms.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/en/terms" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class TermsEn102031 extends CollabLitElement {
        private myMessage;
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/pt/aiFeatures.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/pt/aiFeatures" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class AiFeaturesPt102031 extends CollabLitElement {
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/pt/collabMessages.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/pt/collabMessages" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class CollabMessagesPt102031 extends CollabLitElement {
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/pt/corporate.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/pt/corporate" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class CorporatePt102031 extends CollabLitElement {
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/pt/initial.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/pt/initial" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class Initial102031 extends CollabLitElement {
        private _handleSignIn;
        render(): any;
    }
}
declare module "_102031_/l2/pt/initial2.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/pt/initial2" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class Initial2Pt102031 extends CollabLitElement {
        private _handleAction;
        render(): any;
    }
}
declare module "_102031_/l2/pt/landingpage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/pt/landingpage" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class LandingpagePt102031 extends CollabLitElement {
        private _handleWaitlist;
        render(): any;
    }
}
declare module "_102031_/l2/www/en/aiFeatures.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/aiFeatures" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class AiFeaturesEn102031 extends CollabLitElement {
        private myMessage;
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/www/en/landingpage.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/landingpage" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class LandingpageEn102031 extends CollabLitElement {
        private myMessage;
        private _handleWaitlist;
        render(): any;
    }
}
declare module "_102031_/l2/www/en/teste2.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/en/teste2" {
    import { StateLitElement } from '_100554_/l2/stateLitElement';
    export class Teste1102031 extends StateLitElement {
        name: string;
        render(): any;
    }
}
declare module "_102031_/l2/www/pt/policy.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/pt/policy" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class PolicyPt102031 extends CollabLitElement {
        private _goBack;
        render(): any;
    }
}
declare module "_102031_/l2/www/pt/terms.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102031_/l2/www/pt/terms" {
    import { CollabLitElement } from '_100554_/l2/collabLitElement';
    export class TermsPt102031 extends CollabLitElement {
        private _goBack;
        render(): any;
    }
}
